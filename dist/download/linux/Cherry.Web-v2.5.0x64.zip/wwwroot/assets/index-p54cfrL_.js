import{V as g,gW as k,W as l,Y as s,X as _,d as N,Z as T,a3 as V,aJ as W,ay as z,az as H,hS as A,aC as F,hT as I,bb as M,c as p,o as i,w as o,b as a,g as n,t as S,u as b,l as j,G as J,H as K,B as U,F as X,A as w,n as h,C as Y}from"./index-CQtzqy5y.js";import{b as Z,a as q}from"./headers-DJOnGKei.js";const t="0!important",P="-1px!important";function f(r){return l(`${r}-type`,[s("& +",[g("button",{},[l(`${r}-type`,[_("border",{borderLeftWidth:t}),_("state-border",{left:P})])])])])}function c(r){return l(`${r}-type`,[s("& +",[g("button",[l(`${r}-type`,[_("border",{borderTopWidth:t}),_("state-border",{top:P})])])])])}const O=g("button-group",`
 flex-wrap: nowrap;
 display: inline-flex;
 position: relative;
`,[k("vertical",{flexDirection:"row"},[k("rtl",[g("button",[s("&:first-child:not(:last-child)",`
 margin-right: ${t};
 border-top-right-radius: ${t};
 border-bottom-right-radius: ${t};
 `),s("&:last-child:not(:first-child)",`
 margin-left: ${t};
 border-top-left-radius: ${t};
 border-bottom-left-radius: ${t};
 `),s("&:not(:first-child):not(:last-child)",`
 margin-left: ${t};
 margin-right: ${t};
 border-radius: ${t};
 `),f("default"),l("ghost",[f("primary"),f("info"),f("success"),f("warning"),f("error")])])])]),l("vertical",{flexDirection:"column"},[g("button",[s("&:first-child:not(:last-child)",`
 margin-bottom: ${t};
 margin-left: ${t};
 margin-right: ${t};
 border-bottom-left-radius: ${t};
 border-bottom-right-radius: ${t};
 `),s("&:last-child:not(:first-child)",`
 margin-top: ${t};
 margin-left: ${t};
 margin-right: ${t};
 border-top-left-radius: ${t};
 border-top-right-radius: ${t};
 `),s("&:not(:first-child):not(:last-child)",`
 margin: ${t};
 border-radius: ${t};
 `),c("default"),l("ghost",[c("primary"),c("info"),c("success"),c("warning"),c("error")])])])]),Q={size:{type:String,default:void 0},vertical:Boolean},tt=N({name:"ButtonGroup",props:Q,setup(r){const{mergedClsPrefixRef:u,mergedRtlRef:m}=V(r);return W("-button-group",O,u),H(A,r),{rtlEnabled:z("ButtonGroup",m,u),mergedClsPrefix:u}},render(){const{mergedClsPrefix:r}=this;return T("div",{class:[`${r}-button-group`,this.rtlEnabled&&`${r}-button-group--rtl`,this.vertical&&`${r}-button-group--vertical`],role:"group"},this.$slots)}}),nt=N({__name:"index",setup(r){const u=F(),{hasPermission:m}=I(),{role:y}=u.userInfo,R=["super","admin","user"];function E(v){u.login(v,"123456")}return(v,e)=>{const D=Z,d=U,G=tt,x=q,B=X,L=Y,C=M("permission");return i(),p(L,{title:"权限示例"},{default:o(()=>[a(D,null,{default:o(()=>[n(" 当前权限："+S(b(y)),1)]),_:1}),a(G,null,{default:o(()=>[(i(),j(J,null,K(R,$=>a(d,{key:$,type:"default",onClick:et=>E($)},{default:o(()=>[n(S($),1)]),_:2},1032,["onClick"])),64))]),_:1}),a(x,null,{default:o(()=>e[0]||(e[0]=[n("v-permission 指令用法")])),_:1}),a(B,null,{default:o(()=>[w((i(),p(d,null,{default:o(()=>e[1]||(e[1]=[n(" 仅super可见 ")])),_:1})),[[C,"super"]]),w((i(),p(d,null,{default:o(()=>e[2]||(e[2]=[n(" admin可见 ")])),_:1})),[[C,["admin"]]])]),_:1}),a(x,null,{default:o(()=>e[3]||(e[3]=[n("usePermission 函数用法")])),_:1}),a(B,null,{default:o(()=>[b(m)("super")?(i(),p(d,{key:0},{default:o(()=>e[4]||(e[4]=[n(" super可见 ")])),_:1})):h("",!0),b(m)("admin")?(i(),p(d,{key:1},{default:o(()=>e[5]||(e[5]=[n(" admin可见 ")])),_:1})):h("",!0),b(m)(["admin","user"])?(i(),p(d,{key:2},{default:o(()=>e[6]||(e[6]=[n(" admin和user可见 ")])),_:1})):h("",!0)]),_:1})]),_:1})}}});export{nt as default};
