import{_ as o}from"./Get.vue_vue_type_script_setup_true_lang-B08tcWtk.js";import"./index-CQtzqy5y.js";import"./test-gG1Pr32R.js";export{o as default};
