import{_ as o}from"./FormPost.vue_vue_type_script_setup_true_lang-Di6QG6SE.js";import"./index-BKnuABJD.js";import"./test-DimrdRcg.js";export{o as default};
