import{_ as m}from"./BMap.vue_vue_type_script_setup_true_lang-DeeApz4R.js";import"./index-DvTkVL8H.js";export{m as default};
