import{_ as o}from"./FormPost.vue_vue_type_script_setup_true_lang-D48nNjWR.js";import"./index-CQtzqy5y.js";import"./test-gG1Pr32R.js";export{o as default};
