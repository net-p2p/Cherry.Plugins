import{h8 as o}from"./index-BKnuABJD.js";const n=o(!0);export{n as _};
