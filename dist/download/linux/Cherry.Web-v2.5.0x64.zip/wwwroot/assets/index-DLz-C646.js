import{k as e,l as c,o as n}from"./index-CQtzqy5y.js";const o={};function r(t,s){return n(),c("div",null," 只有超级管理员可见 ")}const _=e(o,[["render",r]]);export{_ as default};
