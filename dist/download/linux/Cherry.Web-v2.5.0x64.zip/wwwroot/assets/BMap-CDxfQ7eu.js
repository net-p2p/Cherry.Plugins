import{_ as m}from"./BMap.vue_vue_type_script_setup_true_lang-BTnho-0l.js";import"./index-BKnuABJD.js";export{m as default};
