import{_ as o}from"./FormPost.vue_vue_type_script_setup_true_lang-DPxwHCaj.js";import"./index-DvTkVL8H.js";import"./test-jMiL3soo.js";export{o as default};
