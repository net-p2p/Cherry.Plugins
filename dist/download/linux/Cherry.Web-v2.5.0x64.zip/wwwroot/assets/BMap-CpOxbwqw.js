import{_ as m}from"./BMap.vue_vue_type_script_setup_true_lang-DZpkfuqu.js";import"./index-CQtzqy5y.js";export{m as default};
