import{ap as K,aq as L,ar as U,as as W,U as G,at as X,V as d,d as F,a3 as j,S as N,au as Y,x as T,a8 as E,a7 as O,Z as p,av as Z,r as J,y as Q,aw as ee,X as v,a2 as R,ax as te,ay as ne,W as P,Y as I,R as ie,az as oe,$ as M,a4 as re,aA as le,aB as k,aC as ae,c as se,o as ce,w as t,b as e,F as ue,C as de,aD as me,j as fe,aj as pe,aE as _e,aF as ve,aG as ge,u as V,B as xe,g as h,I as be,aH as ze}from"./index-CQtzqy5y.js";import{_ as he}from"./chart.vue_vue_type_script_setup_true_lang-Drq7Dnw2.js";import{a as ye,_ as Ce}from"./Grid-DpwJXcg6.js";import{_ as Se}from"./text-BVCgXVpk.js";let A=!1;function we(){if(K&&window.CSS&&!A&&(A=!0,"registerProperty"in window?.CSS))try{CSS.registerProperty({name:"--n-color-start",syntax:"<color>",inherits:!1,initialValue:"#0000"}),CSS.registerProperty({name:"--n-color-end",syntax:"<color>",inherits:!1,initialValue:"#0000"})}catch{}}var $e=1/0,Re=17976931348623157e292;function Te(n){if(!n)return n===0?n:0;if(n=L(n),n===$e||n===-1/0){var o=n<0?-1:1;return o*Re}return n===n?n:0}function Fe(n){var o=Te(n),l=o%1;return o===o?l?o-l:o:0}var Ne=U.isFinite,Pe=Math.min;function Ie(n){var o=Math[n];return function(l,i){if(l=L(l),i=i==null?0:Pe(Fe(i),292),i&&Ne(l)){var r=(W(l)+"e").split("e"),s=o(r[0]+"e"+(+r[1]+i));return r=(W(s)+"e").split("e"),+(r[0]+"e"+(+r[1]-i))}return o(l)}}var ke=Ie("round");function Be(n){const{textColor3:o,infoColor:l,errorColor:i,successColor:r,warningColor:s,textColor1:a,textColor2:c,railColor:m,fontWeightStrong:_,fontSize:f}=n;return Object.assign(Object.assign({},X),{contentFontSize:f,titleFontWeight:_,circleBorder:`2px solid ${o}`,circleBorderInfo:`2px solid ${l}`,circleBorderError:`2px solid ${i}`,circleBorderSuccess:`2px solid ${r}`,circleBorderWarning:`2px solid ${s}`,iconColor:o,iconColorInfo:l,iconColorError:i,iconColorSuccess:r,iconColorWarning:s,titleTextColor:a,contentTextColor:c,metaTextColor:o,lineColor:m})}const Ve={common:G,self:Be},je=d("icon-wrapper",`
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 background-color: var(--n-color);
 display: inline-flex;
 align-items: center;
 justify-content: center;
 color: var(--n-icon-color);
`),Oe=Object.assign(Object.assign({},N.props),{size:{type:Number,default:24},borderRadius:{type:Number,default:6},color:String,iconColor:String}),Ee=F({name:"IconWrapper",props:Oe,setup(n,{slots:o}){const{mergedClsPrefixRef:l,inlineThemeDisabled:i}=j(n),r=N("IconWrapper","-icon-wrapper",je,Y,n,l),s=T(()=>{const{common:{cubicBezierEaseInOut:c},self:{color:m,iconColor:_}}=r.value;return{"--n-bezier":c,"--n-color":m,"--n-icon-color":_}}),a=i?E("icon-wrapper",void 0,s,n):void 0;return()=>{const c=O(n.size);return a?.onRender(),p("div",{class:[`${l.value}-icon-wrapper`,a?.themeClass.value],style:[s?.value,{height:c,width:c,borderRadius:O(n.borderRadius),backgroundColor:n.color,color:n.iconColor}]},o)}}}),We=n=>1-Math.pow(1-n,5);function Me(n){const{from:o,to:l,duration:i,onUpdate:r,onFinish:s}=n,a=performance.now(),c=()=>{const m=performance.now(),_=Math.min(m-a,i),f=o+(l-o)*We(_/i);if(_===i){s();return}r(f),requestAnimationFrame(c)};c()}const Ae={to:{type:Number,default:0},precision:{type:Number,default:0},showSeparator:Boolean,locale:String,from:{type:Number,default:0},active:{type:Boolean,default:!0},duration:{type:Number,default:2e3},onFinish:Function},He=F({name:"NumberAnimation",props:Ae,setup(n){const{localeRef:o}=Z("name"),{duration:l}=n,i=J(n.from),r=T(()=>{const{locale:u}=n;return u!==void 0?u:o.value});let s=!1;const a=u=>{i.value=u},c=()=>{var u;i.value=n.to,s=!1,(u=n.onFinish)===null||u===void 0||u.call(n)},m=(u=n.from,b=n.to)=>{s=!0,i.value=n.from,u!==b&&Me({from:u,to:b,duration:l,onUpdate:a,onFinish:c})},_=T(()=>{var u;const z=ke(i.value,n.precision).toFixed(n.precision).split("."),g=new Intl.NumberFormat(r.value),y=(u=g.formatToParts(.5).find(C=>C.type==="decimal"))===null||u===void 0?void 0:u.value,w=n.showSeparator?g.format(Number(z[0])):z[0],S=z[1];return{integer:w,decimal:S,decimalSeparator:y}});function f(){s||m()}return Q(()=>{ee(()=>{n.active&&m()})}),Object.assign({formattedValue:_},{play:f})},render(){const{formattedValue:{integer:n,decimal:o,decimalSeparator:l}}=this;return[n,o?l:null,o]}}),Le=d("statistic",[v("label",`
 font-weight: var(--n-label-font-weight);
 transition: .3s color var(--n-bezier);
 font-size: var(--n-label-font-size);
 color: var(--n-label-text-color);
 `),d("statistic-value",`
 margin-top: 4px;
 font-weight: var(--n-value-font-weight);
 `,[v("prefix",`
 margin: 0 4px 0 0;
 font-size: var(--n-value-font-size);
 transition: .3s color var(--n-bezier);
 color: var(--n-value-prefix-text-color);
 `,[d("icon",{verticalAlign:"-0.125em"})]),v("content",`
 font-size: var(--n-value-font-size);
 transition: .3s color var(--n-bezier);
 color: var(--n-value-text-color);
 `),v("suffix",`
 margin: 0 0 0 4px;
 font-size: var(--n-value-font-size);
 transition: .3s color var(--n-bezier);
 color: var(--n-value-suffix-text-color);
 `,[d("icon",{verticalAlign:"-0.125em"})])])]),qe=Object.assign(Object.assign({},N.props),{tabularNums:Boolean,label:String,value:[String,Number]}),De=F({name:"Statistic",props:qe,slots:Object,setup(n){const{mergedClsPrefixRef:o,inlineThemeDisabled:l,mergedRtlRef:i}=j(n),r=N("Statistic","-statistic",Le,te,n,o),s=ne("Statistic",i,o),a=T(()=>{const{self:{labelFontWeight:m,valueFontSize:_,valueFontWeight:f,valuePrefixTextColor:x,labelTextColor:u,valueSuffixTextColor:b,valueTextColor:z,labelFontSize:g},common:{cubicBezierEaseInOut:y}}=r.value;return{"--n-bezier":y,"--n-label-font-size":g,"--n-label-font-weight":m,"--n-label-text-color":u,"--n-value-font-weight":f,"--n-value-font-size":_,"--n-value-prefix-text-color":x,"--n-value-suffix-text-color":b,"--n-value-text-color":z}}),c=l?E("statistic",void 0,a,n):void 0;return{rtlEnabled:s,mergedClsPrefix:o,cssVars:l?void 0:a,themeClass:c?.themeClass,onRender:c?.onRender}},render(){var n;const{mergedClsPrefix:o,$slots:{default:l,label:i,prefix:r,suffix:s}}=this;return(n=this.onRender)===null||n===void 0||n.call(this),p("div",{class:[`${o}-statistic`,this.themeClass,this.rtlEnabled&&`${o}-statistic--rtl`],style:this.cssVars},R(i,a=>p("div",{class:`${o}-statistic__label`},this.label||a)),p("div",{class:`${o}-statistic-value`,style:{fontVariantNumeric:this.tabularNums?"tabular-nums":""}},R(r,a=>a&&p("span",{class:`${o}-statistic-value__prefix`},a)),this.value!==void 0?p("span",{class:`${o}-statistic-value__content`},this.value):R(l,a=>a&&p("span",{class:`${o}-statistic-value__content`},a)),R(s,a=>a&&p("span",{class:`${o}-statistic-value__suffix`},a))))}}),H=1.25,Ke=d("timeline",`
 position: relative;
 width: 100%;
 display: flex;
 flex-direction: column;
 line-height: ${H};
`,[P("horizontal",`
 flex-direction: row;
 `,[I(">",[d("timeline-item",`
 flex-shrink: 0;
 padding-right: 40px;
 `,[P("dashed-line-type",[I(">",[d("timeline-item-timeline",[v("line",`
 background-image: linear-gradient(90deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 10px 1px;
 `)])])]),I(">",[d("timeline-item-content",`
 margin-top: calc(var(--n-icon-size) + 12px);
 `,[I(">",[v("meta",`
 margin-top: 6px;
 margin-bottom: unset;
 `)])]),d("timeline-item-timeline",`
 width: 100%;
 height: calc(var(--n-icon-size) + 12px);
 `,[v("line",`
 left: var(--n-icon-size);
 top: calc(var(--n-icon-size) / 2 - 1px);
 right: 0px;
 width: unset;
 height: 2px;
 `)])])])])]),P("right-placement",[d("timeline-item",[d("timeline-item-content",`
 text-align: right;
 margin-right: calc(var(--n-icon-size) + 12px);
 `),d("timeline-item-timeline",`
 width: var(--n-icon-size);
 right: 0;
 `)])]),P("left-placement",[d("timeline-item",[d("timeline-item-content",`
 margin-left: calc(var(--n-icon-size) + 12px);
 `),d("timeline-item-timeline",`
 left: 0;
 `)])]),d("timeline-item",`
 position: relative;
 `,[I("&:last-child",[d("timeline-item-timeline",[v("line",`
 display: none;
 `)]),d("timeline-item-content",[v("meta",`
 margin-bottom: 0;
 `)])]),d("timeline-item-content",[v("title",`
 margin: var(--n-title-margin);
 font-size: var(--n-title-font-size);
 transition: color .3s var(--n-bezier);
 font-weight: var(--n-title-font-weight);
 color: var(--n-title-text-color);
 `),v("content",`
 transition: color .3s var(--n-bezier);
 font-size: var(--n-content-font-size);
 color: var(--n-content-text-color);
 `),v("meta",`
 transition: color .3s var(--n-bezier);
 font-size: 12px;
 margin-top: 6px;
 margin-bottom: 20px;
 color: var(--n-meta-text-color);
 `)]),P("dashed-line-type",[d("timeline-item-timeline",[v("line",`
 --n-color-start: var(--n-line-color);
 transition: --n-color-start .3s var(--n-bezier);
 background-color: transparent;
 background-image: linear-gradient(180deg, var(--n-color-start), var(--n-color-start) 50%, transparent 50%, transparent 100%);
 background-size: 1px 10px;
 `)])]),d("timeline-item-timeline",`
 width: calc(var(--n-icon-size) + 12px);
 position: absolute;
 top: calc(var(--n-title-font-size) * ${H} / 2 - var(--n-icon-size) / 2);
 height: 100%;
 `,[v("circle",`
 border: var(--n-circle-border);
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 width: var(--n-icon-size);
 height: var(--n-icon-size);
 border-radius: var(--n-icon-size);
 box-sizing: border-box;
 `),v("icon",`
 color: var(--n-icon-color);
 font-size: var(--n-icon-size);
 height: var(--n-icon-size);
 width: var(--n-icon-size);
 display: flex;
 align-items: center;
 justify-content: center;
 `),v("line",`
 transition: background-color .3s var(--n-bezier);
 position: absolute;
 top: var(--n-icon-size);
 left: calc(var(--n-icon-size) / 2 - 1px);
 bottom: 0px;
 width: 2px;
 background-color: var(--n-line-color);
 `)])])]),Ue=Object.assign(Object.assign({},N.props),{horizontal:Boolean,itemPlacement:{type:String,default:"left"},size:{type:String,default:"medium"},iconSize:Number}),q=ie("n-timeline"),Ge=F({name:"Timeline",props:Ue,setup(n,{slots:o}){const{mergedClsPrefixRef:l}=j(n),i=N("Timeline","-timeline",Ke,Ve,n,l);return oe(q,{props:n,mergedThemeRef:i,mergedClsPrefixRef:l}),()=>{const{value:r}=l;return p("div",{class:[`${r}-timeline`,n.horizontal&&`${r}-timeline--horizontal`,`${r}-timeline--${n.size}-size`,!n.horizontal&&`${r}-timeline--${n.itemPlacement}-placement`]},o)}}}),Xe={time:[String,Number],title:String,content:String,color:String,lineType:{type:String,default:"default"},type:{type:String,default:"default"}},Ye=F({name:"TimelineItem",props:Xe,slots:Object,setup(n){const o=re(q);o||le("timeline-item","`n-timeline-item` must be placed inside `n-timeline`."),we();const{inlineThemeDisabled:l}=j(),i=T(()=>{const{props:{size:s,iconSize:a},mergedThemeRef:c}=o,{type:m}=n,{self:{titleTextColor:_,contentTextColor:f,metaTextColor:x,lineColor:u,titleFontWeight:b,contentFontSize:z,[k("iconSize",s)]:g,[k("titleMargin",s)]:y,[k("titleFontSize",s)]:w,[k("circleBorder",m)]:S,[k("iconColor",m)]:C},common:{cubicBezierEaseInOut:B}}=c.value;return{"--n-bezier":B,"--n-circle-border":S,"--n-icon-color":C,"--n-content-font-size":z,"--n-content-text-color":f,"--n-line-color":u,"--n-meta-text-color":x,"--n-title-font-size":w,"--n-title-font-weight":b,"--n-title-margin":y,"--n-title-text-color":_,"--n-icon-size":O(a)||g}}),r=l?E("timeline-item",T(()=>{const{props:{size:s,iconSize:a}}=o,{type:c}=n;return`${s[0]}${a||"a"}${c[0]}`}),i,o.props):void 0;return{mergedClsPrefix:o.mergedClsPrefixRef,cssVars:l?void 0:i,themeClass:r?.themeClass,onRender:r?.onRender}},render(){const{mergedClsPrefix:n,color:o,onRender:l,$slots:i}=this;return l?.(),p("div",{class:[`${n}-timeline-item`,this.themeClass,`${n}-timeline-item--${this.type}-type`,`${n}-timeline-item--${this.lineType}-line-type`],style:this.cssVars},p("div",{class:`${n}-timeline-item-timeline`},p("div",{class:`${n}-timeline-item-timeline__line`}),R(i.icon,r=>r?p("div",{class:`${n}-timeline-item-timeline__icon`,style:{color:o}},r):p("div",{class:`${n}-timeline-item-timeline__circle`,style:{borderColor:o}}))),p("div",{class:`${n}-timeline-item-content`},R(i.header,r=>r||this.title?p("div",{class:`${n}-timeline-item-content__title`},r||this.title):null),p("div",{class:`${n}-timeline-item-content__content`},M(i.default,()=>[this.content])),p("div",{class:`${n}-timeline-item-content__meta`},M(i.footer,()=>[this.time]))))}}),tt=F({__name:"index",setup(n){const{userInfo:o}=ae();return(l,i)=>{const r=de,s=pe,a=Ee,c=fe,m=He,_=De,f=me,x=ye,u=Ce,b=xe,z=ge,g=ve,y=_e,w=ue,S=be,C=Se,B=ze,$=Ye,D=Ge;return ce(),se(u,{"x-gap":16,"y-gap":16},{default:t(()=>[e(x,{span:16},{default:t(()=>[e(w,{vertical:"",size:16},{default:t(()=>[e(r,{style:{"--n-padding-left":"0"}},{default:t(()=>[e(he)]),_:1}),e(r,null,{default:t(()=>[e(u,{"x-gap":8,"y-gap":8},{default:t(()=>[e(x,{span:6},{default:t(()=>[e(r,null,{default:t(()=>[e(f,null,{avatar:t(()=>[e(c,null,{default:t(()=>[e(a,{size:46,color:"var(--success-color)","border-radius":999},{default:t(()=>[e(s,{size:26,icon:"icon-park-outline:user"})]),_:1})]),_:1})]),header:t(()=>[e(_,{label:"活跃用户"},{default:t(()=>[e(m,{"show-separator":"",from:0,to:12039})]),_:1})]),_:1})]),_:1})]),_:1}),e(x,{span:6},{default:t(()=>[e(r,null,{default:t(()=>[e(f,null,{avatar:t(()=>[e(c,null,{default:t(()=>[e(a,{size:46,color:"var(--success-color)","border-radius":999},{default:t(()=>[e(s,{size:26,icon:"icon-park-outline:every-user"})]),_:1})]),_:1})]),header:t(()=>[e(_,{label:"用户"},{default:t(()=>[e(m,{"show-separator":"",from:0,to:44039})]),_:1})]),_:1})]),_:1})]),_:1}),e(x,{span:6},{default:t(()=>[e(r,null,{default:t(()=>[e(f,null,{avatar:t(()=>[e(c,null,{default:t(()=>[e(a,{size:46,color:"var(--success-color)","border-radius":999},{default:t(()=>[e(s,{size:26,icon:"icon-park-outline:preview-open"})]),_:1})]),_:1})]),header:t(()=>[e(_,{label:"浏览量"},{default:t(()=>[e(m,{"show-separator":"",from:0,to:551039})]),_:1})]),_:1})]),_:1})]),_:1}),e(x,{span:6},{default:t(()=>[e(r,null,{default:t(()=>[e(f,null,{avatar:t(()=>[e(c,null,{default:t(()=>[e(a,{size:46,color:"var(--success-color)","border-radius":999},{default:t(()=>[e(s,{size:26,icon:"icon-park-outline:star"})]),_:1})]),_:1})]),header:t(()=>[e(_,{label:"客户端连接数"},{default:t(()=>[e(m,{"show-separator":"",from:0,to:7739})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),e(r,{title:"动态"},{"header-extra":t(()=>[e(b,{type:"primary",quaternary:""},{default:t(()=>i[0]||(i[0]=[h(" 更多 ")])),_:1})]),default:t(()=>[e(y,{hoverable:""},{default:t(()=>[e(g,null,{prefix:t(()=>[e(z,{round:"",size:48,src:V(o)?.avatar},null,8,["src"])]),default:t(()=>[e(f,{title:"客怎车","title-extra":"09/29/2022",description:"是“我的客厅怎么会有车”的缩写，指那些在车道间肆意穿梭，把马路当客厅的人，多有嘲讽意味，主要用于车祸视频中。"})]),_:1}),e(g,null,{prefix:t(()=>[e(z,{round:"",size:48,src:V(o)?.avatar},null,8,["src"])]),default:t(()=>[e(f,{title:"街健五大神技","title-extra":"09/29/2022",description:"街头健身五大神技，包括1.单手引体向上。2.慢速双力臂。3.人旗。4.前水平。5.俄式挺身。"})]),_:1}),e(g,null,{prefix:t(()=>[e(z,{round:"",size:48,src:V(o)?.avatar},null,8,["src"])]),default:t(()=>[e(f,{title:"天下岂有七十年太子乎","title-extra":"09/29/2022",description:"★含义：用来调侃由于英国女王超长的在位时间，导致其长子查理斯王子成为史上等待王位时间最久的王储 "})]),_:1}),e(g,null,{prefix:t(()=>[e(z,{round:"",size:48,src:V(o)?.avatar},null,8,["src"])]),default:t(()=>[e(f,{title:"你干嘛～哈哈～哎哟～","title-extra":"09/29/2022",description:"出自著名偶像练习生、练习时长两年半、背带异常梳中分的蔡徐坤在2018年的一档综艺节目偶像练习生中出现的一幕"})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),e(x,{span:8},{default:t(()=>[e(w,{vertical:"",size:16},{default:t(()=>[e(r,{title:"公告"},{"header-extra":t(()=>[e(b,{type:"primary",quaternary:""},{default:t(()=>i[1]||(i[1]=[h(" 更多 ")])),_:1})]),default:t(()=>[e(y,null,{default:t(()=>[e(g,null,{prefix:t(()=>[e(S,{bordered:!1,type:"info",size:"small"},{default:t(()=>i[2]||(i[2]=[h(" 通知 ")])),_:1})]),default:t(()=>[e(b,{text:""},{default:t(()=>i[3]||(i[3]=[h(" 漂洋过海上大专 ")])),_:1})]),_:1}),e(g,null,{prefix:t(()=>[e(S,{bordered:!1,type:"success",size:"small"},{default:t(()=>i[4]||(i[4]=[h(" 消息 ")])),_:1})]),default:t(()=>[e(b,{text:""},{default:t(()=>i[5]||(i[5]=[h(" 你在玩很新的东西 ")])),_:1})]),_:1}),e(g,null,{prefix:t(()=>[e(S,{bordered:!1,type:"warning",size:"small"},{default:t(()=>i[6]||(i[6]=[h(" 活动 ")])),_:1})]),default:t(()=>[e(b,{text:""},{default:t(()=>i[7]||(i[7]=[h(" 上岸第一剑，先斩意中人 ")])),_:1})]),_:1})]),_:1})]),_:1}),e(u,{"x-gap":8,"y-gap":8},{default:t(()=>[e(x,{span:12},{default:t(()=>[e(r,null,{default:t(()=>[e(B,{vertical:"",align:"center"},{default:t(()=>[e(C,{depth:"3"},{default:t(()=>i[8]||(i[8]=[h(" 订单数 ")])),_:1}),e(a,{size:46,"border-radius":999},{default:t(()=>[e(s,{size:26,icon:"icon-park-outline:all-application"})]),_:1}),e(C,{strong:"",class:"text-2xl"},{default:t(()=>i[9]||(i[9]=[h(" 1,234,123 ")])),_:1})]),_:1})]),_:1})]),_:1}),e(x,{span:12},{default:t(()=>[e(r,null,{default:t(()=>[e(B,{vertical:"",align:"center"},{default:t(()=>[e(C,{depth:"3"},{default:t(()=>i[10]||(i[10]=[h(" 待办 ")])),_:1}),e(c,null,{default:t(()=>[e(a,{size:46,color:"var(--warning-color)","border-radius":999},{default:t(()=>[e(s,{size:26,icon:"icon-park-outline:list-bottom"})]),_:1})]),_:1}),e(C,{strong:"",class:"text-2xl"},{default:t(()=>i[11]||(i[11]=[h(" 78 ")])),_:1})]),_:1})]),_:1})]),_:1})]),_:1}),e(r,{title:"任务进度"},{default:t(()=>[e(D,null,{default:t(()=>[e($,{content:"啊"}),e($,{type:"success",title:"成功",content:"哪里成功",time:"2018-04-03 20:46"}),e($,{type:"error",content:"哪里错误",time:"2018-04-03 20:46"}),e($,{type:"warning",title:"警告",content:"哪里警告",time:"2018-04-03 20:46"}),e($,{type:"info",title:"信息",content:"是的",time:"2018-04-03 20:46","line-type":"dashed"}),e($,{content:"啊"})]),_:1})]),_:1})]),_:1})]),_:1})]),_:1})}}});export{tt as default};
