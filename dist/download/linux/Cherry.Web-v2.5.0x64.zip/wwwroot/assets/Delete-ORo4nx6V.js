import{_ as o}from"./Delete.vue_vue_type_script_setup_true_lang-CPwHZSs0.js";import"./index-CQtzqy5y.js";import"./test-gG1Pr32R.js";export{o as default};
