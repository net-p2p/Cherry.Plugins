<<<<<<< HEAD:Cherry.Web/Cherry.Web/wwwroot/assets/index-NsRMR8EO.js
import{V as g,h4 as k,Y as s,W as l,X as _,d as N,Z as V,aJ as z,az as T,i0 as W,ay as A,a7 as F,aC as H,i1 as I,bb as J,o as i,c as p,w as o,b as a,e as n,t as w,u as b,l as M,F as j,D as K,A as S,n as h,B as U,J as X,L as Y}from"./index-BKnuABJD.js";import{b as Z,a as q}from"./headers-j07xIDhr.js";const t="0!important",P="-1px!important";function f(r){return l(`${r}-type`,[s("& +",[g("button",{},[l(`${r}-type`,[_("border",{borderLeftWidth:t}),_("state-border",{left:P})])])])])}function c(r){return l(`${r}-type`,[s("& +",[g("button",[l(`${r}-type`,[_("border",{borderTopWidth:t}),_("state-border",{top:P})])])])])}const O=g("button-group",`
=======
import{v as g,hc as C,z as s,x as l,y as _,d as N,A as M,ax as z,an as H,hX as T,am as V,M as A,aq as I,hY as W,b2 as X,o as i,c as p,w as o,b as a,e as n,t as w,u as b,l as j,gc as q,hM as F,aH as S,n as h,B as K,X as U,a9 as Y}from"./index-DvTkVL8H.js";import{b as J,a as O}from"./headers-BbzDYQUq.js";const t="0!important",P="-1px!important";function c(r){return l(`${r}-type`,[s("& +",[g("button",{},[l(`${r}-type`,[_("border",{borderLeftWidth:t}),_("state-border",{left:P})])])])])}function f(r){return l(`${r}-type`,[s("& +",[g("button",[l(`${r}-type`,[_("border",{borderTopWidth:t}),_("state-border",{top:P})])])])])}const Q=g("button-group",`
>>>>>>> 更新:Cherry.Web/Cherry.Web/wwwroot/assets/index-CikKZUaz.js
 flex-wrap: nowrap;
 display: inline-flex;
 position: relative;
`,[k("vertical",{flexDirection:"row"},[k("rtl",[g("button",[s("&:first-child:not(:last-child)",`
 margin-right: ${t};
 border-top-right-radius: ${t};
 border-bottom-right-radius: ${t};
 `),s("&:last-child:not(:first-child)",`
 margin-left: ${t};
 border-top-left-radius: ${t};
 border-bottom-left-radius: ${t};
 `),s("&:not(:first-child):not(:last-child)",`
 margin-left: ${t};
 margin-right: ${t};
 border-radius: ${t};
 `),f("default"),l("ghost",[f("primary"),f("info"),f("success"),f("warning"),f("error")])])])]),l("vertical",{flexDirection:"column"},[g("button",[s("&:first-child:not(:last-child)",`
 margin-bottom: ${t};
 margin-left: ${t};
 margin-right: ${t};
 border-bottom-left-radius: ${t};
 border-bottom-right-radius: ${t};
 `),s("&:last-child:not(:first-child)",`
 margin-top: ${t};
 margin-left: ${t};
 margin-right: ${t};
 border-top-left-radius: ${t};
 border-top-right-radius: ${t};
 `),s("&:not(:first-child):not(:last-child)",`
 margin: ${t};
 border-radius: ${t};
 `),c("default"),l("ghost",[c("primary"),c("info"),c("success"),c("warning"),c("error")])])])]),Q={size:{type:String,default:void 0},vertical:Boolean},tt=N({name:"ButtonGroup",props:Q,setup(r){const{mergedClsPrefixRef:u,mergedRtlRef:m}=V(r);return z("-button-group",O,u),T(W,r),{rtlEnabled:A("ButtonGroup",m,u),mergedClsPrefix:u}},render(){const{mergedClsPrefix:r}=this;return F("div",{class:[`${r}-button-group`,this.rtlEnabled&&`${r}-button-group--rtl`,this.vertical&&`${r}-button-group--vertical`],role:"group"},this.$slots)}}),nt=N({__name:"index",setup(r){const u=H(),{hasPermission:m}=I(),{role:y}=u.userInfo,R=["super","admin","user"];function D(v){u.login(v,"123456")}return(v,e)=>{const E=Z,d=U,L=tt,x=q,B=X,G=Y,C=J("permission");return i(),p(G,{title:"权限示例"},{default:o(()=>[a(E,null,{default:o(()=>[n(" 当前权限："+w(b(y)),1)]),_:1}),a(L,null,{default:o(()=>[(i(),M(j,null,K(R,$=>a(d,{key:$,type:"default",onClick:et=>D($)},{default:o(()=>[n(w($),1)]),_:2},1032,["onClick"])),64))]),_:1}),a(x,null,{default:o(()=>e[0]||(e[0]=[n("v-permission 指令用法")])),_:1}),a(B,null,{default:o(()=>[S((i(),p(d,null,{default:o(()=>e[1]||(e[1]=[n(" 仅super可见 ")])),_:1})),[[C,"super"]]),S((i(),p(d,null,{default:o(()=>e[2]||(e[2]=[n(" admin可见 ")])),_:1})),[[C,["admin"]]])]),_:1}),a(x,null,{default:o(()=>e[3]||(e[3]=[n("usePermission 函数用法")])),_:1}),a(B,null,{default:o(()=>[b(m)("super")?(i(),p(d,{key:0},{default:o(()=>e[4]||(e[4]=[n(" super可见 ")])),_:1})):h("",!0),b(m)("admin")?(i(),p(d,{key:1},{default:o(()=>e[5]||(e[5]=[n(" admin可见 ")])),_:1})):h("",!0),b(m)(["admin","user"])?(i(),p(d,{key:2},{default:o(()=>e[6]||(e[6]=[n(" admin和user可见 ")])),_:1})):h("",!0)]),_:1})]),_:1})}}});export{nt as default};
