<<<<<<< HEAD:Cherry.Web/Cherry.Web/wwwroot/assets/DownLoadWithProgress.vue_vue_type_script_setup_true_lang-D5jQy6KV.js
import{Y as R,V as l,W as w,d as z,x as $,a2 as C,a7 as r,a9 as T,hG as A,hE as G,hu as j,hF as V,Z as H,R as Y,hR as X,aB as I,a3 as E,r as F,hS as U,o as Z,c as J,w as B,b as k,u as P,i as K,a as q,t as O,e as L,C as Q,B as ee,J as re,L as te}from"./index-BKnuABJD.js";import{d as ie}from"./test-DimrdRcg.js";const oe=R([l("progress",{display:"inline-block"},[l("progress-icon",`
=======
import{z as R,v as l,x as w,d as z,F as $,G as C,M as r,O as T,hx as A,hv as G,he as j,hw as H,A as V,p as X,hJ as Y,ap as I,H as F,r as E,hK as U,o as K,c as J,w as B,b as k,u as P,i as Z,a as q,t as O,e as L,W as Q,B as ee,X as re,a9 as te}from"./index-DvTkVL8H.js";import{d as ie}from"./test-jMiL3soo.js";const oe=R([l("progress",{display:"inline-block"},[l("progress-icon",`
>>>>>>> 更新:Cherry.Web/Cherry.Web/wwwroot/assets/DownLoadWithProgress.vue_vue_type_script_setup_true_lang-DPchFonn.js
 color: var(--n-icon-color);
 transition: color .3s var(--n-bezier);
 `),w("line",`
 width: 100%;
 display: block;
 `,[l("progress-content",`
 display: flex;
 align-items: center;
 `,[l("progress-graph",{flex:1})]),l("progress-custom-content",{marginLeft:"14px"}),l("progress-icon",`
 width: 30px;
 padding-left: 14px;
 height: var(--n-icon-size-line);
 line-height: var(--n-icon-size-line);
 font-size: var(--n-icon-size-line);
 `,[w("as-text",`
 color: var(--n-text-color-line-outer);
 text-align: center;
 width: 40px;
 font-size: var(--n-font-size);
 padding-left: 4px;
 transition: color .3s var(--n-bezier);
 `)])]),w("circle, dashboard",{width:"120px"},[l("progress-custom-content",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 `),l("progress-text",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: inherit;
 font-size: var(--n-font-size-circle);
 color: var(--n-text-color-circle);
 font-weight: var(--n-font-weight-circle);
 transition: color .3s var(--n-bezier);
 white-space: nowrap;
 `),l("progress-icon",`
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 color: var(--n-icon-color);
 font-size: var(--n-icon-size-circle);
 `)]),w("multiple-circle",`
 width: 200px;
 color: inherit;
 `,[l("progress-text",`
 font-weight: var(--n-font-weight-circle);
 color: var(--n-text-color-circle);
 position: absolute;
 left: 50%;
 top: 50%;
 transform: translateX(-50%) translateY(-50%);
 display: flex;
 align-items: center;
 justify-content: center;
 transition: color .3s var(--n-bezier);
 `)]),l("progress-content",{position:"relative"}),l("progress-graph",{position:"relative"},[l("progress-graph-circle",[R("svg",{verticalAlign:"bottom"}),l("progress-graph-circle-fill",`
 stroke: var(--n-fill-color);
 transition:
 opacity .3s var(--n-bezier),
 stroke .3s var(--n-bezier),
 stroke-dasharray .3s var(--n-bezier);
 `,[w("empty",{opacity:0})]),l("progress-graph-circle-rail",`
 transition: stroke .3s var(--n-bezier);
 overflow: hidden;
 stroke: var(--n-rail-color);
 `)]),l("progress-graph-line",[w("indicator-inside",[l("progress-graph-line-rail",`
 height: 16px;
 line-height: 16px;
 border-radius: 10px;
 `,[l("progress-graph-line-fill",`
 height: inherit;
 border-radius: 10px;
 `),l("progress-graph-line-indicator",`
 background: #0000;
 white-space: nowrap;
 text-align: right;
 margin-left: 14px;
 margin-right: 14px;
 height: inherit;
 font-size: 12px;
 color: var(--n-text-color-line-inner);
 transition: color .3s var(--n-bezier);
 `)])]),w("indicator-inside-label",`
 height: 16px;
 display: flex;
 align-items: center;
 `,[l("progress-graph-line-rail",`
 flex: 1;
 transition: background-color .3s var(--n-bezier);
 `),l("progress-graph-line-indicator",`
 background: var(--n-fill-color);
 font-size: 12px;
 transform: translateZ(0);
 display: flex;
 vertical-align: middle;
 height: 16px;
 line-height: 16px;
 padding: 0 10px;
 border-radius: 10px;
 position: absolute;
 white-space: nowrap;
 color: var(--n-text-color-line-inner);
 transition:
 right .2s var(--n-bezier),
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier);
 `)]),l("progress-graph-line-rail",`
 position: relative;
 overflow: hidden;
 height: var(--n-rail-height);
 border-radius: 5px;
 background-color: var(--n-rail-color);
 transition: background-color .3s var(--n-bezier);
 `,[l("progress-graph-line-fill",`
 background: var(--n-fill-color);
 position: relative;
 border-radius: 5px;
 height: inherit;
 width: 100%;
 max-width: 0%;
 transition:
 background-color .3s var(--n-bezier),
 max-width .2s var(--n-bezier);
 `,[w("processing",[R("&::after",`
 content: "";
 background-image: var(--n-line-bg-processing);
 animation: progress-processing-animation 2s var(--n-bezier) infinite;
 `)])])])])])]),R("@keyframes progress-processing-animation",`
 0% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 100%;
 opacity: 1;
 }
 66% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 100% {
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 opacity: 0;
 }
 `)]),ne={success:r(A,null),error:r(G,null),warning:r(j,null),info:r(V,null)},ae=z({name:"ProgressLine",props:{clsPrefix:{type:String,required:!0},percentage:{type:Number,default:0},railColor:String,railStyle:[String,Object],fillColor:String,status:{type:String,required:!0},indicatorPlacement:{type:String,required:!0},indicatorTextColor:String,unit:{type:String,default:"%"},processing:{type:Boolean,required:!0},showIndicator:{type:Boolean,required:!0},height:[String,Number],railBorderRadius:[String,Number],fillBorderRadius:[String,Number]},setup(e,{slots:h}){const f=$(()=>C(e.height)),o=$(()=>e.railBorderRadius!==void 0?C(e.railBorderRadius):e.height!==void 0?C(e.height,{c:.5}):""),i=$(()=>e.fillBorderRadius!==void 0?C(e.fillBorderRadius):e.railBorderRadius!==void 0?C(e.railBorderRadius):e.height!==void 0?C(e.height,{c:.5}):"");return()=>{const{indicatorPlacement:a,railColor:m,railStyle:c,percentage:g,unit:d,indicatorTextColor:y,status:u,showIndicator:s,fillColor:t,processing:p,clsPrefix:n}=e;return r("div",{class:`${n}-progress-content`,role:"none"},r("div",{class:`${n}-progress-graph`,"aria-hidden":!0},r("div",{class:[`${n}-progress-graph-line`,{[`${n}-progress-graph-line--indicator-${a}`]:!0}]},r("div",{class:`${n}-progress-graph-line-rail`,style:[{backgroundColor:m,height:f.value,borderRadius:o.value},c]},r("div",{class:[`${n}-progress-graph-line-fill`,p&&`${n}-progress-graph-line-fill--processing`],style:{maxWidth:`${e.percentage}%`,backgroundColor:t,height:f.value,lineHeight:f.value,borderRadius:i.value}},a==="inside"?r("div",{class:`${n}-progress-graph-line-indicator`,style:{color:y}},h.default?h.default():`${g}${d}`):null)))),s&&a==="outside"?r("div",null,h.default?r("div",{class:`${n}-progress-custom-content`,style:{color:y},role:"none"},h.default()):u==="default"?r("div",{role:"none",class:`${n}-progress-icon ${n}-progress-icon--as-text`,style:{color:y}},g,d):r("div",{class:`${n}-progress-icon`,"aria-hidden":!0},r(T,{clsPrefix:n},{default:()=>ne[u]}))):null)}}}),se={success:r(A,null),error:r(G,null),warning:r(j,null),info:r(V,null)},le=z({name:"ProgressCircle",props:{clsPrefix:{type:String,required:!0},status:{type:String,required:!0},strokeWidth:{type:Number,required:!0},fillColor:String,railColor:String,railStyle:[String,Object],percentage:{type:Number,default:0},offsetDegree:{type:Number,default:0},showIndicator:{type:Boolean,required:!0},indicatorTextColor:String,unit:String,viewBoxWidth:{type:Number,required:!0},gapDegree:{type:Number,required:!0},gapOffsetDegree:{type:Number,default:0}},setup(e,{slots:h}){function f(o,i,a){const{gapDegree:m,viewBoxWidth:c,strokeWidth:g}=e,d=50,y=0,u=d,s=0,t=2*d,p=50+g/2,n=`M ${p},${p} m ${y},${u}
      a ${d},${d} 0 1 1 ${s},${-t}
      a ${d},${d} 0 1 1 ${-s},${t}`,b=Math.PI*2*d,x={stroke:a,strokeDasharray:`${o/100*(b-m)}px ${c*8}px`,strokeDashoffset:`-${m/2}px`,transformOrigin:i?"center":void 0,transform:i?`rotate(${i}deg)`:void 0};return{pathString:n,pathStyle:x}}return()=>{const{fillColor:o,railColor:i,strokeWidth:a,offsetDegree:m,status:c,percentage:g,showIndicator:d,indicatorTextColor:y,unit:u,gapOffsetDegree:s,clsPrefix:t}=e,{pathString:p,pathStyle:n}=f(100,0,i),{pathString:b,pathStyle:x}=f(g,m,o),v=100+a;return r("div",{class:`${t}-progress-content`,role:"none"},r("div",{class:`${t}-progress-graph`,"aria-hidden":!0},r("div",{class:`${t}-progress-graph-circle`,style:{transform:s?`rotate(${s}deg)`:void 0}},r("svg",{viewBox:`0 0 ${v} ${v}`},r("g",null,r("path",{class:`${t}-progress-graph-circle-rail`,d:p,"stroke-width":a,"stroke-linecap":"round",fill:"none",style:n})),r("g",null,r("path",{class:[`${t}-progress-graph-circle-fill`,g===0&&`${t}-progress-graph-circle-fill--empty`],d:b,"stroke-width":a,"stroke-linecap":"round",fill:"none",style:x}))))),d?r("div",null,h.default?r("div",{class:`${t}-progress-custom-content`,role:"none"},h.default()):c!=="default"?r("div",{class:`${t}-progress-icon`,"aria-hidden":!0},r(T,{clsPrefix:t},{default:()=>se[c]})):r("div",{class:`${t}-progress-text`,style:{color:y},role:"none"},r("span",{class:`${t}-progress-text__percentage`},g),r("span",{class:`${t}-progress-text__unit`},u))):null)}}});function M(e,h,f=100){return`m ${f/2} ${f/2-e} a ${e} ${e} 0 1 1 0 ${2*e} a ${e} ${e} 0 1 1 0 -${2*e}`}const ce=z({name:"ProgressMultipleCircle",props:{clsPrefix:{type:String,required:!0},viewBoxWidth:{type:Number,required:!0},percentage:{type:Array,default:[0]},strokeWidth:{type:Number,required:!0},circleGap:{type:Number,required:!0},showIndicator:{type:Boolean,required:!0},fillColor:{type:Array,default:()=>[]},railColor:{type:Array,default:()=>[]},railStyle:{type:Array,default:()=>[]}},setup(e,{slots:h}){const f=$(()=>e.percentage.map((i,a)=>`${Math.PI*i/100*(e.viewBoxWidth/2-e.strokeWidth/2*(1+2*a)-e.circleGap*a)*2}, ${e.viewBoxWidth*8}`));return()=>{const{viewBoxWidth:o,strokeWidth:i,circleGap:a,showIndicator:m,fillColor:c,railColor:g,railStyle:d,percentage:y,clsPrefix:u}=e;return r("div",{class:`${u}-progress-content`,role:"none"},r("div",{class:`${u}-progress-graph`,"aria-hidden":!0},r("div",{class:`${u}-progress-graph-circle`},r("svg",{viewBox:`0 0 ${o} ${o}`},y.map((s,t)=>r("g",{key:t},r("path",{class:`${u}-progress-graph-circle-rail`,d:M(o/2-i/2*(1+2*t)-a*t,i,o),"stroke-width":i,"stroke-linecap":"round",fill:"none",style:[{strokeDashoffset:0,stroke:g[t]},d[t]]}),r("path",{class:[`${u}-progress-graph-circle-fill`,s===0&&`${u}-progress-graph-circle-fill--empty`],d:M(o/2-i/2*(1+2*t)-a*t,i,o),"stroke-width":i,"stroke-linecap":"round",fill:"none",style:{strokeDasharray:f.value[t],strokeDashoffset:0,stroke:c[t]}})))))),m&&h.default?r("div",null,r("div",{class:`${u}-progress-text`},h.default())):null)}}}),de=Object.assign(Object.assign({},Y.props),{processing:Boolean,type:{type:String,default:"line"},gapDegree:Number,gapOffsetDegree:Number,status:{type:String,default:"default"},railColor:[String,Array],railStyle:[String,Array],color:[String,Array],viewBoxWidth:{type:Number,default:100},strokeWidth:{type:Number,default:7},percentage:[Number,Array],unit:{type:String,default:"%"},showIndicator:{type:Boolean,default:!0},indicatorPosition:{type:String,default:"outside"},indicatorPlacement:{type:String,default:"outside"},indicatorTextColor:String,circleGap:{type:Number,default:1},height:Number,borderRadius:[String,Number],fillBorderRadius:[String,Number],offsetDegree:Number}),ue=z({name:"Progress",props:de,setup(e){const h=$(()=>e.indicatorPlacement||e.indicatorPosition),f=$(()=>{if(e.gapDegree||e.gapDegree===0)return e.gapDegree;if(e.type==="dashboard")return 75}),{mergedClsPrefixRef:o,inlineThemeDisabled:i}=H(e),a=Y("Progress","-progress",oe,X,e,o),m=$(()=>{const{status:g}=e,{common:{cubicBezierEaseInOut:d},self:{fontSize:y,fontSizeCircle:u,railColor:s,railHeight:t,iconSizeCircle:p,iconSizeLine:n,textColorCircle:b,textColorLineInner:x,textColorLineOuter:v,lineBgProcessing:_,fontWeightCircle:D,[I("iconColor",g)]:N,[I("fillColor",g)]:S}}=a.value;return{"--n-bezier":d,"--n-fill-color":S,"--n-font-size":y,"--n-font-size-circle":u,"--n-font-weight-circle":D,"--n-icon-color":N,"--n-icon-size-circle":p,"--n-icon-size-line":n,"--n-line-bg-processing":_,"--n-rail-color":s,"--n-rail-height":t,"--n-text-color-circle":b,"--n-text-color-line-inner":x,"--n-text-color-line-outer":v}}),c=i?E("progress",$(()=>e.status[0]),m,e):void 0;return{mergedClsPrefix:o,mergedIndicatorPlacement:h,gapDeg:f,cssVars:i?void 0:m,themeClass:c?.themeClass,onRender:c?.onRender}},render(){const{type:e,cssVars:h,indicatorTextColor:f,showIndicator:o,status:i,railColor:a,railStyle:m,color:c,percentage:g,viewBoxWidth:d,strokeWidth:y,mergedIndicatorPlacement:u,unit:s,borderRadius:t,fillBorderRadius:p,height:n,processing:b,circleGap:x,mergedClsPrefix:v,gapDeg:_,gapOffsetDegree:D,themeClass:N,$slots:S,onRender:W}=this;return W?.(),r("div",{class:[N,`${v}-progress`,`${v}-progress--${e}`,`${v}-progress--${i}`],style:h,"aria-valuemax":100,"aria-valuemin":0,"aria-valuenow":g,role:e==="circle"||e==="line"||e==="dashboard"?"progressbar":"none"},e==="circle"||e==="dashboard"?r(le,{clsPrefix:v,status:i,showIndicator:o,indicatorTextColor:f,railColor:a,fillColor:c,railStyle:m,offsetDegree:this.offsetDegree,percentage:g,viewBoxWidth:d,strokeWidth:y,gapDegree:_===void 0?e==="dashboard"?75:0:_,gapOffsetDegree:D,unit:s},S):e==="line"?r(ae,{clsPrefix:v,status:i,showIndicator:o,indicatorTextColor:f,railColor:a,fillColor:c,railStyle:m,percentage:g,processing:b,indicatorPlacement:u,unit:s,fillBorderRadius:p,railBorderRadius:t,height:n},S):e==="multiple-circle"?r(ce,{clsPrefix:v,strokeWidth:y,railColor:a,fillColor:c,railStyle:m,viewBoxWidth:d,percentage:g,showIndicator:o,circleGap:x},S):null)}}),fe=z({__name:"DownLoadWithProgress",emits:["update"],setup(e,{emit:h}){const f=h,o=F("https://images.unsplash.com/photo-1663529628961-80aa6ebcd157?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=764&q=80"),{downloading:i,abort:a,send:m,data:c}=U(ie(o.value),{immediate:!1}),g=$(()=>i.value.loaded?Math.floor(i.value.loaded/i.value.total*100):0);async function d(){await m(),f("update","fileOk"),y(c.value,"fileOk")}function y(u,s){const t=URL.createObjectURL(u),p=document.createElement("a");p.download=s,p.style.display="none",p.href=t,document.body.appendChild(p),p.click(),document.body.removeChild(p)}return(u,s)=>{const t=Q,p=ue,n=ee,b=re,x=te;return Z(),J(x,{title:"带进度的下载文件",size:"small"},{default:B(()=>[k(b,{vertical:""},{default:B(()=>[k(t,{value:P(o),"onUpdate:value":s[0]||(s[0]=v=>K(o)?o.value=v:null)},null,8,["value"]),q("div",null,"文件大小："+O(P(i).total)+"B",1),q("div",null,"已下载："+O(P(i).loaded)+"B",1),k(p,{type:"line","indicator-placement":"inside",percentage:P(g)},null,8,["percentage"]),k(b,null,{default:B(()=>[k(n,{strong:"",secondary:"",onClick:d},{default:B(()=>s[1]||(s[1]=[L(" 开始下载 ")])),_:1}),k(n,{strong:"",secondary:"",type:"warning",onClick:P(a)},{default:B(()=>s[2]||(s[2]=[L(" 中断下载 ")])),_:1},8,["onClick"])]),_:1})]),_:1})]),_:1})}}});export{fe as _};
