import{h0 as o}from"./index-CQtzqy5y.js";const n=o(!0);export{n as _};
