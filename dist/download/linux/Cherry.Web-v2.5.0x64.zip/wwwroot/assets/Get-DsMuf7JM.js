import{_ as o}from"./Get.vue_vue_type_script_setup_true_lang-4a7yG8zo.js";import"./index-BKnuABJD.js";import"./test-DimrdRcg.js";export{o as default};
