import{_ as o}from"./Get.vue_vue_type_script_setup_true_lang-B8CH24gT.js";import"./index-DvTkVL8H.js";import"./test-jMiL3soo.js";export{o as default};
