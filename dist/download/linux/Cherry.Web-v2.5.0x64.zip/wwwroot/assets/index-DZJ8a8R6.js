import{z as f,v as t,hc as W,x as B,y as N,gT as X,gU as K,d as E,A as Z,p as H,hZ as J,F as q,ap as V,H as Q,gX as Y,hm as ee,M as a,ha as te,hn as oe,aq as re,r as F,o as ne,c as le,w as i,b as n,u as b,e as I,t as j,as as se,X as ae,a9 as ie,W as de,B as ce}from"./index-DvTkVL8H.js";import{a as pe,_ as be}from"./FormItem-BfGpqLe4.js";function U(l,g="default",s=[]){const{children:c}=l;if(c!==null&&typeof c=="object"&&!Array.isArray(c)){const r=c[g];if(typeof r=="function")return r()}return s}const G="DESCRIPTION_ITEM_FLAG";function ue(l){return typeof l=="object"&&l&&!Array.isArray(l)?l.type&&l.type[G]:!1}const ge=f([t("descriptions",{fontSize:"var(--n-font-size)"},[t("descriptions-separator",`
 display: inline-block;
 margin: 0 8px 0 2px;
 `),t("descriptions-table-wrapper",[t("descriptions-table",[t("descriptions-table-row",[t("descriptions-table-header",{padding:"var(--n-th-padding)"}),t("descriptions-table-content",{padding:"var(--n-td-padding)"})])])]),W("bordered",[t("descriptions-table-wrapper",[t("descriptions-table",[t("descriptions-table-row",[f("&:last-child",[t("descriptions-table-content",{paddingBottom:0})])])])])]),B("left-label-placement",[t("descriptions-table-content",[f("> *",{verticalAlign:"top"})])]),B("left-label-align",[f("th",{textAlign:"left"})]),B("center-label-align",[f("th",{textAlign:"center"})]),B("right-label-align",[f("th",{textAlign:"right"})]),B("bordered",[t("descriptions-table-wrapper",`
 border-radius: var(--n-border-radius);
 overflow: hidden;
 background: var(--n-merged-td-color);
 border: 1px solid var(--n-merged-border-color);
 `,[t("descriptions-table",[t("descriptions-table-row",[f("&:not(:last-child)",[t("descriptions-table-content",{borderBottom:"1px solid var(--n-merged-border-color)"}),t("descriptions-table-header",{borderBottom:"1px solid var(--n-merged-border-color)"})]),t("descriptions-table-header",`
 font-weight: 400;
 background-clip: padding-box;
 background-color: var(--n-merged-th-color);
 `,[f("&:not(:last-child)",{borderRight:"1px solid var(--n-merged-border-color)"})]),t("descriptions-table-content",[f("&:not(:last-child)",{borderRight:"1px solid var(--n-merged-border-color)"})])])])])]),t("descriptions-header",`
 font-weight: var(--n-th-font-weight);
 font-size: 18px;
 transition: color .3s var(--n-bezier);
 line-height: var(--n-line-height);
 margin-bottom: 16px;
 color: var(--n-title-text-color);
 `),t("descriptions-table-wrapper",`
 transition:
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[t("descriptions-table",`
 width: 100%;
 border-collapse: separate;
 border-spacing: 0;
 box-sizing: border-box;
 `,[t("descriptions-table-row",`
 box-sizing: border-box;
 transition: border-color .3s var(--n-bezier);
 `,[t("descriptions-table-header",`
 font-weight: var(--n-th-font-weight);
 line-height: var(--n-line-height);
 display: table-cell;
 box-sizing: border-box;
 color: var(--n-th-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `),t("descriptions-table-content",`
 vertical-align: top;
 line-height: var(--n-line-height);
 display: table-cell;
 box-sizing: border-box;
 color: var(--n-td-text-color);
 transition:
 color .3s var(--n-bezier),
 background-color .3s var(--n-bezier),
 border-color .3s var(--n-bezier);
 `,[N("content",`
 transition: color .3s var(--n-bezier);
 display: inline-block;
 color: var(--n-td-text-color);
 `)]),N("label",`
 font-weight: var(--n-th-font-weight);
 transition: color .3s var(--n-bezier);
 display: inline-block;
 margin-right: 14px;
 color: var(--n-th-text-color);
 `)])])])]),t("descriptions-table-wrapper",`
 --n-merged-th-color: var(--n-th-color);
 --n-merged-td-color: var(--n-td-color);
 --n-merged-border-color: var(--n-border-color);
 `),X(t("descriptions-table-wrapper",`
 --n-merged-th-color: var(--n-th-color-modal);
 --n-merged-td-color: var(--n-td-color-modal);
 --n-merged-border-color: var(--n-border-color-modal);
 `)),K(t("descriptions-table-wrapper",`
 --n-merged-th-color: var(--n-th-color-popover);
 --n-merged-td-color: var(--n-td-color-popover);
 --n-merged-border-color: var(--n-border-color-popover);
 `))]),he=Object.assign(Object.assign({},H.props),{title:String,column:{type:Number,default:3},columns:Number,labelPlacement:{type:String,default:"top"},labelAlign:{type:String,default:"left"},separator:{type:String,default:":"},size:{type:String,default:"medium"},bordered:Boolean,labelClass:String,labelStyle:[Object,String],contentClass:String,contentStyle:[Object,String]}),me=E({name:"Descriptions",props:he,setup(l){const{mergedClsPrefixRef:g,inlineThemeDisabled:s}=Z(l),c=H("Descriptions","-descriptions",ge,J,l,g),r=q(()=>{const{size:u,bordered:h}=l,{common:{cubicBezierEaseInOut:d},self:{titleTextColor:S,thColor:_,thColorModal:o,thColorPopover:v,thTextColor:y,thFontWeight:w,tdTextColor:x,tdColor:T,tdColorModal:$,tdColorPopover:e,borderColor:P,borderColorModal:M,borderColorPopover:m,borderRadius:C,lineHeight:R,[V("fontSize",u)]:k,[V(h?"thPaddingBordered":"thPadding",u)]:z,[V(h?"tdPaddingBordered":"tdPadding",u)]:A}}=c.value;return{"--n-title-text-color":S,"--n-th-padding":z,"--n-td-padding":A,"--n-font-size":k,"--n-bezier":d,"--n-th-font-weight":w,"--n-line-height":R,"--n-th-text-color":y,"--n-td-text-color":x,"--n-th-color":_,"--n-th-color-modal":o,"--n-th-color-popover":v,"--n-td-color":T,"--n-td-color-modal":$,"--n-td-color-popover":e,"--n-border-radius":C,"--n-border-color":P,"--n-border-color-modal":M,"--n-border-color-popover":m}}),p=s?Q("descriptions",q(()=>{let u="";const{size:h,bordered:d}=l;return d&&(u+="a"),u+=h[0],u}),r,l):void 0;return{mergedClsPrefix:g,cssVars:s?void 0:r,themeClass:p?.themeClass,onRender:p?.onRender,compitableColumn:Y(l,["columns","column"]),inlineThemeDisabled:s}},render(){const l=this.$slots.default,g=l?ee(l()):[];g.length;const{contentClass:s,labelClass:c,compitableColumn:r,labelPlacement:p,labelAlign:u,size:h,bordered:d,title:S,cssVars:_,mergedClsPrefix:o,separator:v,onRender:y}=this;y?.();const w=g.filter(e=>ue(e)),x={span:0,row:[],secondRow:[],rows:[]},$=w.reduce((e,P,M)=>{const m=P.props||{},C=w.length-1===M,R=["label"in m?m.label:U(P,"label")],k=[U(P)],z=m.span||1,A=e.span;e.span+=z;const O=m.labelStyle||m["label-style"]||this.labelStyle,D=m.contentStyle||m["content-style"]||this.contentStyle;if(p==="left")d?e.row.push(a("th",{class:[`${o}-descriptions-table-header`,c],colspan:1,style:O},R),a("td",{class:[`${o}-descriptions-table-content`,s],colspan:C?(r-A)*2+1:z*2-1,style:D},k)):e.row.push(a("td",{class:`${o}-descriptions-table-content`,colspan:C?(r-A)*2:z*2},a("span",{class:[`${o}-descriptions-table-content__label`,c],style:O},[...R,v&&a("span",{class:`${o}-descriptions-separator`},v)]),a("span",{class:[`${o}-descriptions-table-content__content`,s],style:D},k)));else{const L=C?(r-A)*2:z*2;e.row.push(a("th",{class:[`${o}-descriptions-table-header`,c],colspan:L,style:O},R)),e.secondRow.push(a("td",{class:[`${o}-descriptions-table-content`,s],colspan:L,style:D},k))}return(e.span>=r||C)&&(e.span=0,e.row.length&&(e.rows.push(e.row),e.row=[]),p!=="left"&&e.secondRow.length&&(e.rows.push(e.secondRow),e.secondRow=[])),e},x).rows.map(e=>a("tr",{class:`${o}-descriptions-table-row`},e));return a("div",{style:_,class:[`${o}-descriptions`,this.themeClass,`${o}-descriptions--${p}-label-placement`,`${o}-descriptions--${u}-label-align`,`${o}-descriptions--${h}-size`,d&&`${o}-descriptions--bordered`]},S||this.$slots.header?a("div",{class:`${o}-descriptions-header`},S||oe(this,"header")):null,a("div",{class:`${o}-descriptions-table-wrapper`},a("table",{class:`${o}-descriptions-table`},a("tbody",null,p==="top"&&a("tr",{class:`${o}-descriptions-table-row`,style:{visibility:"collapse"}},te(r*2,a("td",null))),$))))}}),fe={label:String,span:{type:Number,default:1},labelClass:String,labelStyle:[Object,String],contentClass:String,contentStyle:[Object,String]},_e=E({name:"DescriptionsItem",[G]:!0,props:fe,render(){return null}}),we=E({__name:"index",setup(l){const g=re(),{userInfo:s}=g,c=F(),r=F({user:{name:"",age:""},phone:""}),p={user:{name:{required:!0,message:"请输入姓名",trigger:"blur"},age:{required:!0,message:"请输入年龄",trigger:["input","blur"]}},phone:{required:!0,message:"请输入电话号码",trigger:["input"]}};function u(){c.value?.validate(h=>{h?window.$message.error("验证不通过"):window.$message.success("验证通过")})}return(h,d)=>{const S=se,_=_e,o=me,v=ae,y=ie,w=de,x=pe,T=ce,$=be;return ne(),le(v,{vertical:""},{default:i(()=>[n(y,{title:"个人信息"},{default:i(()=>[n(v,{size:"large"},{default:i(()=>[n(S,{round:"",size:128,src:b(s)?.avatar},null,8,["src"]),n(o,{"label-placement":"left",column:2,title:`傍晚好，${b(s)?.nickname}，这里是简单的个人中心模板`},{default:i(()=>[n(_,{label:"id"},{default:i(()=>[I(j(b(s)?.id),1)]),_:1}),n(_,{label:"用户名"},{default:i(()=>[I(j(b(s)?.userName),1)]),_:1}),n(_,{label:"真实名称"},{default:i(()=>[I(j(b(s)?.nickname),1)]),_:1}),n(_,{label:"角色"},{default:i(()=>[I(j(b(s)?.role),1)]),_:1})]),_:1},8,["title"])]),_:1})]),_:1}),n(y,{title:"信息修改"},{default:i(()=>[n(v,{justify:"center"},{default:i(()=>[n($,{ref_key:"formRef",ref:c,class:"w-500px","label-width":80,model:b(r),rules:p},{default:i(()=>[n(x,{label:"姓名",path:"user.name"},{default:i(()=>[n(w,{value:b(r).user.name,"onUpdate:value":d[0]||(d[0]=e=>b(r).user.name=e),placeholder:"输入姓名"},null,8,["value"])]),_:1}),n(x,{label:"年龄",path:"user.age"},{default:i(()=>[n(w,{value:b(r).user.age,"onUpdate:value":d[1]||(d[1]=e=>b(r).user.age=e),placeholder:"输入年龄"},null,8,["value"])]),_:1}),n(x,{label:"电话号码",path:"phone"},{default:i(()=>[n(w,{value:b(r).phone,"onUpdate:value":d[2]||(d[2]=e=>b(r).phone=e),placeholder:"电话号码"},null,8,["value"])]),_:1}),n(x,null,{default:i(()=>[n(T,{type:"primary","attr-type":"button",block:"",onClick:u},{default:i(()=>d[3]||(d[3]=[I(" 验证 ")])),_:1})]),_:1})]),_:1},8,["model"])]),_:1})]),_:1})]),_:1})}}});export{we as default};
