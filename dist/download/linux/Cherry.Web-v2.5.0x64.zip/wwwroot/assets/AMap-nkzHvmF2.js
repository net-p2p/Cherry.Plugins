import{_ as m}from"./AMap.vue_vue_type_script_setup_true_lang-DmigDgyl.js";import"./index-CQtzqy5y.js";export{m as default};
